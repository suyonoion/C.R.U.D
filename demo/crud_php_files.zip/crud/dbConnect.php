<?php
/* author: Ridwan website: http://blogciqwan.com/ */ 
//Defining Constants 
define('HOST','mysql.idhostinger.com'); //host
define('USER','u12345678_xxxx'); //user
define('PASS','123456'); //password
define('DB','u12345678_xxxx'); //nama database
//Connecting to Database 
$con = mysqli_connect(HOST,USER,PASS,DB) or die('Unable to Connect'); ?>